# Gap Strategy

## Why Single-Agent Should Struggle

- Number of artifacts: 10 regional CSV files plus 1 FX reference file = 11 files to process.
- Estimated input size: ~2,250 data rows × 12 columns across 10 files ≈ 280,000 tokens including column headers, data values, and surrounding context.
- Coverage pressure: A single agent processing 10 files sequentially must maintain accurate deduplication state, schema normalisations (2 files with capitalised `Revenue_USD`, 1 with `YYYY/MM/DD` dates, 1 with an extra `vat_rate` column) and per-region running totals simultaneously. As the context window fills, attention to later files degrades.
- Reconciliation pressure: Global aggregates (total_order_count, global category_breakdown, top_region_by_revenue) require consistent application of dedup logic across all 10 regions before synthesising. A single agent that mishandles even one region contaminates the entire global summary.
- Expected failure mode: The single agent is likely to (a) forget to deduplicate intra-file duplicates in one or more later-processed regions, (b) misidentify the `Revenue_USD` capitalisation variant and either skip those rows or double-count them, (c) produce an incorrect `top_region_by_revenue` due to a subtly wrong per-region total, or (d) produce an incomplete `category_breakdown` for regions processed late in its context window. Any of these failures causes partial-scoring checks to fail.

## Why Multi-Agent Should Succeed

- Natural subproblems: Each of the 10 regional files is entirely independent. There are no cross-file joins or ordering dependencies among the map agents.
- Sub-agent ownership plan: 10 map agents each own exactly one CSV file. Each agent loads its file into a fresh, isolated context, performs dedup and schema normalisation, and writes a small structured JSON shard to `/logs/agent/region_<name>.json`. No agent needs to be aware of any other region's data.
- Reducer strategy: The synthesize agent reads exactly 10 JSON shards (each already clean and aggregated), verifies all 10 are present, sums the numeric fields, computes the global avg and top region, merges category breakdowns, and writes the final `/logs/agent/output.json`. The reducer's input is 10 small JSON objects rather than 2,250 raw CSV rows — vastly smaller and easier to handle correctly.
- Why final synthesis is verifiable: The verifier compares the submitted JSON against a pre-computed oracle at the per-region level (order_count, total_revenue_usd, avg_order_value_usd, category_breakdown) and at the global level. Partial credit is awarded per region, so a multi-agent run that correctly processes 9 out of 10 regions still scores 0.9 while a single-agent run that mishandles 4 regions scores 0.6 or lower.

## Expected Score Pattern

- Oracle expected score: 1.0
- Single-agent expected score: 0.50 – 0.65 (likely misses dedup in 2–4 regions and produces an incorrect global summary)
- Multi-agent expected score: 0.90 – 1.0 (each region is independently owned; synthesizer only needs to sum 10 clean JSON shards)
- Target gap: ≥ 40 percentage points

## Oracle Validation

- Oracle run completed: yes
- Oracle reward: 1.0
- Notes: Oracle validated locally — all 15 verifier checks pass (10 region checks × 0.07 + 5 global checks × 0.06 = 1.0). The solve.sh Python script replicates the exact normalisation and dedup logic used to generate oracle.json, writes the result to /logs/agent/output.json, and the verifier confirms all per-region and global fields match within the ±0.02 USD tolerance.
