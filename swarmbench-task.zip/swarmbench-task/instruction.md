# Global Sales Reconciliation and Analysis

## Background

You are working with the quarterly sales data for a global e-commerce company, OmniCart. The data team has exported one CSV file per region, totalling 10 regional files. These files have been collected from different internal systems and contain several known data quality issues that must be resolved before any aggregation is performed.

## Input Artifacts

All input files are located at `/input_artifacts/`:

| File | Region | Currency |
|------|--------|----------|
| `sales_north_america.csv` | North America | USD |
| `sales_europe_west.csv` | Europe West | EUR |
| `sales_europe_east.csv` | Europe East | EUR |
| `sales_uk.csv` | United Kingdom | GBP |
| `sales_latam.csv` | Latin America | BRL |
| `sales_mea.csv` | Middle East & Africa | AED |
| `sales_apac_east.csv` | Asia-Pacific East | JPY |
| `sales_apac_south.csv` | Asia-Pacific South | INR |
| `sales_oceania.csv` | Oceania | AUD |
| `sales_canada.csv` | Canada | CAD |
| `fx_rates.csv` | FX reference table | — |

## Known Data Quality Issues

Each regional file may contain one or more of the following issues:

1. Intra-file duplicate orders — some `order_id` values appear more than once within the same file. Keep only the first occurrence.
2. Inconsistent column names — some files use `Revenue_USD` (capitalised) instead of `revenue_usd`. Treat these as the same field.
3. Date format inconsistency — some files use `YYYY/MM/DD` instead of `YYYY-MM-DD`. Normalise all dates to `YYYY-MM-DD`.
4. Extra columns — some files contain additional columns not present in others (e.g. `vat_rate`). Ignore extra columns.
5. Missing values — some rows have empty `customer_id` or `product_name` fields. Retain these rows (do not drop them); simply leave those fields blank in analysis.

## Required Output

Produce a single JSON file at `/logs/agent/output.json` with the following structure:

```json
{
  "regions": {
    "<region_name>": {
      "order_count": <int>,
      "total_quantity": <int>,
      "total_revenue_usd": <float, rounded to 2 decimal places>,
      "avg_order_value_usd": <float, rounded to 2 decimal places>,
      "category_breakdown": {
        "<category>": {
          "order_count": <int>,
          "revenue_usd": <float, rounded to 2 decimal places>
        }
      }
    }
  },
  "global": {
    "total_order_count": <int>,
    "total_quantity": <int>,
    "total_revenue_usd": <float, rounded to 2 decimal places>,
    "avg_order_value_usd": <float, rounded to 2 decimal places>,
    "top_region_by_revenue": "<region_name>",
    "category_breakdown": {
      "<category>": {
        "order_count": <int>,
        "revenue_usd": <float, rounded to 2 decimal places>
      }
    }
  }
}
```

## Success Criteria

- All 10 regional files are processed.
- Intra-file duplicate `order_id` values are removed (first occurrence kept).
- All revenue values are expressed in USD (use `revenue_usd` or `Revenue_USD` column — do not perform currency conversion yourself; this column is pre-computed in each file).
- `order_count` reflects deduplicated rows per region.
- `total_quantity` is the sum of the `quantity` column after deduplication.
- `avg_order_value_usd` = `total_revenue_usd` / `order_count`, rounded to 2 decimal places.
- `top_region_by_revenue` is the region key string (e.g. `"uk"`) with the highest `total_revenue_usd`.
- `category_breakdown` is present and correct for every region and for the global summary.
- The output file is valid JSON at exactly `/logs/agent/output.json`.

## Constraints

- Use only the data in `/input_artifacts/`. Do not fetch external data.
- The `fx_rates.csv` file is provided for reference only; revenue conversion is already reflected in the `revenue_usd`/`Revenue_USD` columns.
- Do not drop rows with missing `customer_id` or `product_name`.
- Process all 10 regions; partial output will receive partial credit only.
