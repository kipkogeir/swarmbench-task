#!/usr/bin/env python3
"""
Verifier for the OmniCart Sales Reconciliation task.

Scoring breakdown (total = 1.0):
  - Per-region checks (10 regions × 0.07 = 0.70):
      Each region earns 0.07 if order_count, total_revenue_usd,
      avg_order_value_usd, and category_breakdown are all correct.
  - Global summary checks (0.30 total):
      total_order_count          0.06
      total_revenue_usd          0.06
      avg_order_value_usd        0.06
      top_region_by_revenue      0.06
      global category_breakdown  0.06
"""

import json
import math
import os
import sys
from pathlib import Path

AGENT_OUTPUT = "/logs/agent/output.json"
ORACLE_PATH  = "/solution/oracle.json"
TOLERANCE    = 0.02   # USD tolerance for float comparisons
LOG_DIR      = Path("/logs/verifier")

REGIONS = [
    "north_america", "europe_west", "europe_east", "uk", "latam",
    "mea", "apac_east", "apac_south", "oceania", "canada",
]
CATEGORIES = [
    "Electronics", "Apparel", "Home & Garden", "Sports",
    "Books", "Toys", "Beauty", "Automotive",
]

# --- helpers -----------------------------------------------------------------

def fclose(a, b, tol=TOLERANCE):
    try:
        return math.isclose(float(a), float(b), abs_tol=tol)
    except Exception:
        return False

def load_json(path):
    with open(path) as f:
        return json.load(f)

# --- main --------------------------------------------------------------------

score = 0.0
checks = []

def add(name, passed, weight, detail=""):
    global score
    checks.append((name, passed, weight, detail))
    if passed:
        score += weight

# Load oracle
oracle = load_json(ORACLE_PATH)

# Load agent output
try:
    agent = load_json(AGENT_OUTPUT)
except FileNotFoundError:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.joinpath("reward.txt").write_text("0.0")
    print(f"FATAL: {AGENT_OUTPUT} not found. Score = 0.0")
    sys.exit(1)
except json.JSONDecodeError as e:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.joinpath("reward.txt").write_text("0.0")
    print(f"FATAL: {AGENT_OUTPUT} is not valid JSON: {e}. Score = 0.0")
    sys.exit(1)

# --- per-region checks (0.07 each) -------------------------------------------

PER_REGION_WEIGHT = 0.07

for region in REGIONS:
    o_reg = oracle["regions"].get(region, {})
    a_reg = (agent.get("regions") or {}).get(region, {})

    ok_count   = a_reg.get("order_count") == o_reg.get("order_count")
    ok_rev     = fclose(a_reg.get("total_revenue_usd", 0), o_reg.get("total_revenue_usd", 0))
    ok_avg     = fclose(a_reg.get("avg_order_value_usd", 0), o_reg.get("avg_order_value_usd", 0))

    # category_breakdown check: all categories must be present and correct
    o_cats = o_reg.get("category_breakdown", {})
    a_cats = a_reg.get("category_breakdown", {})
    cat_ok = True
    for cat, o_data in o_cats.items():
        a_data = a_cats.get(cat, {})
        if a_data.get("order_count") != o_data["order_count"]:
            cat_ok = False
            break
        if not fclose(a_data.get("revenue_usd", 0), o_data["revenue_usd"]):
            cat_ok = False
            break

    all_ok = ok_count and ok_rev and ok_avg and cat_ok
    detail = (
        f"order_count={'OK' if ok_count else f'FAIL(got {a_reg.get(\"order_count\")}, want {o_reg.get(\"order_count\")})'} "
        f"revenue={'OK' if ok_rev else f'FAIL(got {a_reg.get(\"total_revenue_usd\")}, want {o_reg.get(\"total_revenue_usd\")})'} "
        f"avg={'OK' if ok_avg else f'FAIL(got {a_reg.get(\"avg_order_value_usd\")}, want {o_reg.get(\"avg_order_value_usd\")})'} "
        f"categories={'OK' if cat_ok else 'FAIL'}"
    )
    add(f"region_{region}", all_ok, PER_REGION_WEIGHT, detail)

# --- global summary checks (0.06 each) ---------------------------------------

GLOBAL_WEIGHT = 0.06
o_gl = oracle.get("global", {})
a_gl = (agent.get("global") or {})

add("global_total_order_count",
    a_gl.get("total_order_count") == o_gl.get("total_order_count"),
    GLOBAL_WEIGHT,
    f"got {a_gl.get('total_order_count')}, want {o_gl.get('total_order_count')}")

add("global_total_revenue_usd",
    fclose(a_gl.get("total_revenue_usd", 0), o_gl.get("total_revenue_usd", 0)),
    GLOBAL_WEIGHT,
    f"got {a_gl.get('total_revenue_usd')}, want {o_gl.get('total_revenue_usd')}")

add("global_avg_order_value_usd",
    fclose(a_gl.get("avg_order_value_usd", 0), o_gl.get("avg_order_value_usd", 0)),
    GLOBAL_WEIGHT,
    f"got {a_gl.get('avg_order_value_usd')}, want {o_gl.get('avg_order_value_usd')}")

add("global_top_region_by_revenue",
    a_gl.get("top_region_by_revenue") == o_gl.get("top_region_by_revenue"),
    GLOBAL_WEIGHT,
    f"got '{a_gl.get('top_region_by_revenue')}', want '{o_gl.get('top_region_by_revenue')}'")

o_gcats = o_gl.get("category_breakdown", {})
a_gcats = a_gl.get("category_breakdown", {})
gcat_ok = True
for cat, o_data in o_gcats.items():
    a_data = a_gcats.get(cat, {})
    if a_data.get("order_count") != o_data["order_count"]:
        gcat_ok = False
        break
    if not fclose(a_data.get("revenue_usd", 0), o_data["revenue_usd"], tol=0.10):
        gcat_ok = False
        break
add("global_category_breakdown", gcat_ok, GLOBAL_WEIGHT)

# --- report ------------------------------------------------------------------

final_score = round(score, 4)
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG_DIR.joinpath("reward.txt").write_text(str(final_score))

print(f"\n{'='*60}")
print(f"OmniCart Sales Reconciliation Verifier")
print(f"{'='*60}")
for name, passed, weight, detail in checks:
    status = "PASS" if passed else "FAIL"
    print(f"  [{status}] {name:<42} weight={weight:.2f}  {detail}")
print(f"{'='*60}")
print(f"  FINAL SCORE: {final_score}")
print(f"{'='*60}\n")

sys.exit(0 if final_score >= 0.99 else 1)
