#!/bin/bash
# Oracle solution for the OmniCart Sales Reconciliation task.
# Reads all 10 regional CSV files, deduplicates, normalises schemas,
# computes per-region and global metrics, then writes output.json.
set -e

mkdir -p /logs/agent

python3 - << 'PYEOF'
import csv
import json
import math
import os

DATA_DIR = "/input_artifacts"

REGIONS = [
    "north_america", "europe_west", "europe_east", "uk", "latam",
    "mea", "apac_east", "apac_south", "oceania", "canada",
]


def normalize_row(row, region):
    """
    Normalise a raw CSV row dict. Returns a clean dict or None if the row
    cannot be used (e.g. missing revenue_usd field entirely).
    """
    # Normalise revenue_usd column name (some files use Revenue_USD)
    rev_usd_raw = row.get("revenue_usd") or row.get("Revenue_USD") or ""
    if not rev_usd_raw:
        return None
    try:
        rev_usd = float(rev_usd_raw)
    except ValueError:
        return None

    # Normalise date format
    order_date = row.get("order_date", "").strip().replace("/", "-")

    return {
        "order_id":    row.get("order_id", "").strip(),
        "order_date":  order_date,
        "product_sku": row.get("product_sku", "").strip(),
        "category":    row.get("category", "").strip(),
        "quantity":    int(row.get("quantity", 0)),
        "revenue_usd": rev_usd,
        "region":      region,
    }


results = {}

for region in REGIONS:
    path = os.path.join(DATA_DIR, f"sales_{region}.csv")
    seen_orders = set()
    rows = []

    with open(path, newline="", encoding="utf-8") as f:
        for raw in csv.DictReader(f):
            n = normalize_row(raw, region)
            if n is None:
                continue
            oid = n["order_id"]
            if oid in seen_orders:
                continue  # skip intra-file duplicate
            seen_orders.add(oid)
            rows.append(n)

    total_revenue_usd = round(sum(r["revenue_usd"] for r in rows), 2)
    total_quantity    = sum(r["quantity"] for r in rows)
    order_count       = len(rows)

    category_breakdown = {}
    for r in rows:
        cat = r["category"]
        if cat not in category_breakdown:
            category_breakdown[cat] = {"order_count": 0, "revenue_usd": 0.0}
        category_breakdown[cat]["order_count"] += 1
        category_breakdown[cat]["revenue_usd"] += r["revenue_usd"]
    for cat in category_breakdown:
        category_breakdown[cat]["revenue_usd"] = round(
            category_breakdown[cat]["revenue_usd"], 2
        )

    results[region] = {
        "order_count":        order_count,
        "total_quantity":     total_quantity,
        "total_revenue_usd":  total_revenue_usd,
        "avg_order_value_usd": round(total_revenue_usd / order_count, 2)
                               if order_count else 0.0,
        "category_breakdown": category_breakdown,
    }

# --- global aggregates -------------------------------------------------------

global_revenue      = sum(results[r]["total_revenue_usd"] for r in REGIONS)
global_order_count  = sum(results[r]["order_count"]       for r in REGIONS)
global_quantity     = sum(results[r]["total_quantity"]     for r in REGIONS)
top_region          = max(REGIONS, key=lambda r: results[r]["total_revenue_usd"])

global_cats = {}
for region in REGIONS:
    for cat, data in results[region]["category_breakdown"].items():
        if cat not in global_cats:
            global_cats[cat] = {"order_count": 0, "revenue_usd": 0.0}
        global_cats[cat]["order_count"] += data["order_count"]
        global_cats[cat]["revenue_usd"] += data["revenue_usd"]
for cat in global_cats:
    global_cats[cat]["revenue_usd"] = round(global_cats[cat]["revenue_usd"], 2)

output = {
    "regions": results,
    "global": {
        "total_order_count":    global_order_count,
        "total_quantity":       global_quantity,
        "total_revenue_usd":    round(global_revenue, 2),
        "avg_order_value_usd":  round(global_revenue / global_order_count, 2)
                                if global_order_count else 0.0,
        "top_region_by_revenue": top_region,
        "category_breakdown":   global_cats,
    }
}

with open("/logs/agent/output.json", "w") as f:
    json.dump(output, f, indent=2)

print("Oracle solve complete. Output written to /logs/agent/output.json")
PYEOF
